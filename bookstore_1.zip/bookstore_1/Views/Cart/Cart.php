<?php include '../../templates/header.php'; ?>
<h2>Your Cart</h2>

<?php if (!empty($cartItems)) : ?>
    <table>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Action</th>
        </tr>
        <?php foreach ($cartItems as $id => $item) : ?>
            <tr>
                <td><?php echo htmlspecialchars($item['title']); ?></td>
                <td><?php echo htmlspecialchars($item['author']); ?></td>
                <td>$<?php echo number_format($item['price'], 2); ?></td>
                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                <td>
                    <form action="../Controller/BooksController.php?action=remove_from_cart" method="post">
                        <input type="hidden" name="book_id" value="<?php echo htmlspecialchars($id); ?>">
                        <input type="submit" value="Remove">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="4" style="text-align: right;"><strong>Total:</strong></td>
            <td colspan="2">$<?php echo number_format($this->cartModel->getTotal(), 2); ?></td>
        </tr>
    </table>
<?php else : ?>
    <p>Your cart is empty.</p>
<?php endif; ?>
<?php include '../../templates/footer.php'; ?>
