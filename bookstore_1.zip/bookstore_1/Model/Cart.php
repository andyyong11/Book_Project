<?php
class Cart {
    public function __construct() {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
    }

    // Add item to the cart
    public function addItem($id, $title, $author, $price, $quantity) {
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$id] = [
                'title' => $title,
                'author' => $author,
                'price' => $price,
                'quantity' => $quantity
            ];
        }
    }

    // Get all items in the cart
    public function getItems() {
        return $_SESSION['cart'];
    }

    // Remove an item from the cart
    public function removeItem($id) {
        unset($_SESSION['cart'][$id]);
    }

    // Calculate the total
    public function getTotal() {
        $total = 0;
        foreach ($_SESSION['cart'] as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        return $total;
    }
}
?>
